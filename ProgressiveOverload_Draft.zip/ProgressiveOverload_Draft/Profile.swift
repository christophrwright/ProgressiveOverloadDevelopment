

class userProfile{
    var userName:String
    var age:Int
    var gender:String
    var height:Int
    var weight:Int
    var routines[Exercize]
    var history[NSDate:[Exercize]]
    var avaliableEquipment:[String]

}
