class Schedule{
    var exercise:Exercise
    var routine:Routine // [Exercise]
    var scheduledDayForExercise:[NSDate:Routine]

    func setDayOfWeek()

    func checkMuscleGroup(){

    }


    func skipDay(){

    }

    func showCurrentRoutine(){

    }

}
